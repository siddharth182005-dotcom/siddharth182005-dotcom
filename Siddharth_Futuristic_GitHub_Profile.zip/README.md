<div align="center">

<!-- Keep assets/futuristic-profile-banner.png in the same repository as this README. -->
<img src="assets/futuristic-profile-banner.png" alt="Siddharth Gunjan — futuristic neon developer profile concept" width="100%">

# 👋 Siddharth Gunjan
### Full-Stack Developer · AI Enthusiast · Problem Solver

**Code · Create · Learn · Grow · Repeat**

<a href="https://nyaya-ai-legal.vercel.app"><img src="https://img.shields.io/badge/Explore-Nyaya%20AI-7C3AED?style=for-the-badge&logo=vercel&logoColor=white" alt="Nyaya AI"></a>
<a href="https://leetcode.com/u/siddharth-gunjan/"><img src="https://img.shields.io/badge/LeetCode-Profile-F59E0B?style=for-the-badge&logo=leetcode&logoColor=white" alt="LeetCode"></a>
<a href="mailto:siddharth18.2005@gmail.com"><img src="https://img.shields.io/badge/Contact-Email-06B6D4?style=for-the-badge&logo=gmail&logoColor=white" alt="Email"></a>

</div>

---

<table>
<tr>
<td width="35%" valign="top">

## ◈ About Me

- 🎓 B.Tech CSE, Galgotias University
- 📍 India
- 💻 Full-Stack Developer
- 🤖 AI Enthusiast
- 🧩 DSA and problem solving

### Connect
- [GitHub](https://github.com/siddharth182005-dotcom)
- [LeetCode](https://leetcode.com/u/siddharth-gunjan/)
- [Email](mailto:siddharth18.2005@gmail.com)

</td>
<td width="65%" valign="top">

## 🌌 Welcome to my digital universe

I build practical web applications and explore AI-powered solutions that make technology more useful, accessible, and intuitive. I enjoy learning by building, solving problems, and improving each iteration.

> *Turning ideas into real-world solutions, one commit at a time.*

</td>
</tr>
</table>

## ⚡ Tech Stack

<div align="center">
<img src="https://skillicons.dev/icons?i=java,js,html,css,react,nodejs,python,mysql,git,github,vscode&theme=dark" alt="Tech stack icons">
</div>

## 🚀 Featured Projects

<table>
<tr>
<td width="50%" valign="top">

### ⚖️ Nyaya AI
AI-assisted legal assistance web application.

<a href="https://nyaya-ai-legal.vercel.app"><img src="https://img.shields.io/badge/OPEN%20LIVE%20PROJECT-7C3AED?style=for-the-badge&logo=vercel&logoColor=white" alt="Open Nyaya AI"></a>

</td>
<td width="50%" valign="top">

### 🧮 CodSoft Calculator
A frontend calculator project focused on layout and interactive behavior.

<a href="https://github.com/siddharth182005-dotcom/CodSoft-Calculator"><img src="https://img.shields.io/badge/VIEW%20REPOSITORY-111827?style=for-the-badge&logo=github&logoColor=white" alt="View CodSoft Calculator"></a>

</td>
</tr>
</table>

<div align="center">
<a href="https://github.com/siddharth182005-dotcom?tab=repositories"><img src="https://img.shields.io/badge/Explore%20More%20Projects-0891B2?style=for-the-badge&logo=github&logoColor=white" alt="More projects"></a>
</div>

## 📊 GitHub Command Center

<div align="center">
<img height="170" src="https://github-readme-stats.vercel.app/api?username=siddharth182005-dotcom&show_icons=true&hide_border=true&rank_icon=github&theme=tokyonight&bg_color=070B18&title_color=22D3EE&icon_color=C084FC&text_color=E5E7EB" alt="GitHub statistics">
<img height="170" src="https://github-readme-stats.vercel.app/api/top-langs/?username=siddharth182005-dotcom&layout=compact&hide_border=true&theme=tokyonight&bg_color=070B18&title_color=22D3EE&text_color=E5E7EB" alt="Top languages">
<br>
<img width="95%" src="https://github-readme-streak-stats.herokuapp.com/?user=siddharth182005-dotcom&hide_border=true&theme=tokyonight&background=070B18&ring=C084FC&fire=22D3EE&currStreakLabel=E5E7EB" alt="GitHub streak">
<img width="95%" src="https://github-readme-activity-graph.vercel.app/graph?username=siddharth182005-dotcom&bg_color=070B18&color=E5E7EB&line=7C3AED&point=22D3EE&area=true&hide_border=true" alt="GitHub activity graph">
</div>

## 🧩 Problem Solving

<div align="center">
<a href="https://leetcode.com/u/siddharth-gunjan/"><img src="https://leetcard.jacoblin.cool/siddharth-gunjan?theme=dark&font=Baloo&ext=heatmap" alt="LeetCode profile card"></a>
</div>

## ⌁ Let's Connect

<div align="center">
<a href="mailto:siddharth18.2005@gmail.com"><img src="https://img.shields.io/badge/EMAIL-EA4335?style=for-the-badge&logo=gmail&logoColor=white" alt="Email"></a>
<a href="https://github.com/siddharth182005-dotcom"><img src="https://img.shields.io/badge/GITHUB-181717?style=for-the-badge&logo=github&logoColor=white" alt="GitHub"></a>
<a href="https://leetcode.com/u/siddharth-gunjan/"><img src="https://img.shields.io/badge/LEETCODE-F59E0B?style=for-the-badge&logo=leetcode&logoColor=white" alt="LeetCode"></a>
<!-- Replace this with your actual LinkedIn profile URL. -->
<a href="https://www.linkedin.com/"><img src="https://img.shields.io/badge/LINKEDIN-0A66C2?style=for-the-badge&logo=linkedin&logoColor=white" alt="LinkedIn"></a>
<br><br>
<img src="https://capsule-render.vercel.app/api?type=waving&height=120&section=footer&color=0:00D9FF,50:30105C,100:090B1A" width="100%" alt="Neon footer">
**Thanks for visiting — keep building. 🚀**
</div>
